Requirements:
1) Install python
2) install scikitlearn (for SVM classifier)
3) install nltk (for lemmatization and removing stop words)
4) install pillow (for saving graphs in png format)
5) install matplotlib (for graphs)

Run project:
open Text Emotion Detection.IPYNB file using Jupyter notebook.
Execute each cell sequencially from top to bottom.


